
public class humandata {

	public static void main(String[] args) {
//		ADD DATA TYPES
        String first_name = "Jay Z";
        String last_name = "Carter";
        String street_address = "123 5th ave";
        String city = "Brooklyn";
        int zip_code = 11205;

// 		PRINT DATA  
        System.out.println("First name: " + first_name);
        System.out.println("Last name: " + last_name);
        System.out.println("Street address: " + street_address);
        System.out.println("City: " + city);
        System.out.println("Zip_code: " + zip_code);

	}

}
